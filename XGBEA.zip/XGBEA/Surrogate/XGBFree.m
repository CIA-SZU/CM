function XGBFree(Models)
%% Free all the internal structure to prevent  memory leak
    M = numel(Models);
    for i = 1 : M
        xgboost_free(Models{i});
    end
end

