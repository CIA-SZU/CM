function Y = XGBPredict(XGBModels, decs)
% Predict the objective values of input variables
% Input:
%       Models : a cell of trained models.
%         decs : a Q×R matrix with Q samples of R features.
% Output:
%           Y  : a Q×M matrix represents the predict values of Q samples on M objective functions. 
    M = numel(XGBModels);
    N = size(decs, 1);
    Y = zeros(N, M);
    for i = 1 : M
        Y(:, i) = xgboost_test(decs, XGBModels{i});
    end
end

