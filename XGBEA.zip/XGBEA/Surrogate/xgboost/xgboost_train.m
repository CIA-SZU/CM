function model = xgboost_train(Xtrain, ytrain, depth)
%% Function inputs:
%       Xtrain:        matrix of inputs for the training set
%       ytrain:        vetor of labels/values for the test set
%% Function output:
%       model: a structure containing:
%           booster_handle; pointer to the final model
%           params;        model parameters (just for info)
%% params:
%%% General Parameters:
%       booster: Chose which booster for boosting
%            -default:  gbtree  
%            -options: gbtree, dart, gblinear
%       nthread: Number of parallel threads used to run XGBoost
%            -default:  maximum available  
%            -options: [1, maxinum]
%%% Parameters for Tree Booster:
%       eta: Learning rate.
%            -default:  0.3  
%            -options: [0, 1]
%       gammma: Minimum loss reduction required to make a further partition on a leaf node of the tree.
%            -default:  0  
%            -options: [0, +inf]
%       max_depth: Maximum depth of a tree.
%            -default:  6  
%            -options: [0, +inf](0 is only accepted in lossguided growing policy when tree_method is set as hist)
%       subsample: Subsample ratio of the training instances.
%            -default:  1  
%            -options: (0, 1]
%       colsample_bytree: the subsample ratio of columns when constructing each tree.
%            -default:  1  
%            -options: (0, 1]
%       lambda: L2 regularization term on weights.
%            -default:  1  
%            -options: 
%       alpha: L1 regularization term on weights.
%            -default:  0 
%            -options: 
%       process_type: A type of boosting process to run.
%            -default:  default.  The normal boosting process which creates new trees.
%            -options: update. Starts from an existing model and only updates its trees.
%       num_parallel_tree: Number of parallel trees constructed during each iteration. This option is used to support boosted random forest.
%            -default:  1
%            -options:
%%% Learning Task Parameters:
%       objective: Learning objective.
%            -default:  reg:squarederror 
%            -options: 
%               - reg:squarederror:     regression with squared loss.
%               - reg:pseudohubererror: regression with Pseudo Huber loss, a twice differentiable alternative to absolute loss.
%       metric: Evaluation metrics for validation data. .
%            -default:  rmse  
%            -options: according to objective,rmse for regression, and error for classification
%               - rmse: root mean square error
%               - mae:  mean absolute error
%               - mphe: mean Pseudo Huber error. Default metric of reg:pseudohubererror objective
%               - auc:  Area under the curve
%% Command Line Parameters
%   num_round:   The number of rounds for boosting.
%   save_period: The period to save the model.
%       - default: 0
%   task: XGBoost task.
%       - default: train
%       - options: 
%           - train: training using data
%           - pred:  making prediction for test:data
%           - eval:  for evaluating statistics specified by eval[name]=filename
%           - dump:  for dump the learned model into text format  
%   model_in:  Path to input model, needed for test, eval, dump tasks. If it is specified in training, XGBoost will continue training from the input model.
%       - default: NULL
%   model_out: Path to output model after training finishes
%       - default: NULL
%   model_dir: The output directory of the saved models during training
%       - default: models/
%   dump_format: Format of model dump file
%       - default: text
%       - options: text,json
%   name_dump: Name of model dump file
%       - default: dump.txt
%   name_pred: Name of prediction file, used in pred mode
%       - default: pred.txt
%% DLL function
% % % % % % % % % % % % % % % % % % % % % % % % 
% int XGBoosterCreate(  const DMatrixHandle dmats[],
%                       bst_ulong           len,
%                       BoosterHandle*      out 
% )	
% Description:  create xgboost learner
% Parameters:
%       dmats	matrices that are set to be cached
%       len     length of dmats
%       out     handle to the result booster
% Returns:
%       0 when success, -1 when failure happens
% % % % % % % % % % % % % % % % % % % % % % % % 

% % % % % % % % % % % % % % % % % % % % % % % % 
% int XGBoosterSaveModel(   BoosterHandle 	handle,
%                           const char * 	fname 
% )	
% Description:  Save model into existing file.
% Parameters:
%       handle	handle
%       fname   file name
% Returns:
%       0 when success, -1 when failure happens
% % % % % % % % % % % % % % % % % % % % % % % % 
% int XGBoosterSetParam(   BoosterHandle 	handle,
%                          const char * 	name 
%                          const char * 	value 
% )	
% Description:  set parameters.
% Parameters:
%       handle	handle
%       name	parameter name
%       value	value of parameter
% Returns:
%       0 when success, -1 when failure happens
% % % % % % % % % % % % % % % % % % % % % % % % 
% int XGBoosterUpdateOneIter(   BoosterHandle 	handle,
%                               int 	iter, 
%                               DMatrixHandle 	dtrain 
% )	
% Description:  update the model in one round using dtrain
% Parameters:
%       handle	handle
%       iter	current iteration rounds
%       dtrain	training data
% Returns:
%       0 when success, -1 when failure happens
% % % % % % % % % % % % % % % % % % % % % % % % 
%% Prepare params
params = struct;
params.nthread           = ceil(size(Xtrain, 2)/15) ;
params.tree_method       = 'exact';
params.objective         = 'reg:squarederror';
params.eval_metric       = 'rmse'; 
params.booster           = 'gbtree';
params.eta               = 0.1;
%params.gammma            = 10;
params.max_depth         = depth;
params.subsample         = 0.6;
params.colsample_bytree  = 0.8;
params.min_child_weight  = 1;

max_num_iters            = 200;
%% Store into fileds
param_fields = fields(params);
for i=1:length(param_fields)
    eval(['params.' param_fields{i} ' = num2str(params.' param_fields{i} ');'])
end

%% Load the xgboost library
if not(libisloaded('xgboost'))
    filepath = mfilename('fullpath');
    [dirpath, ~] = fileparts(filepath);
    libfolder = [dirpath, filesep, 'lib'];
    try
        [~,~]=loadlibrary([libfolder,filesep,'xgboost'], [libfolder,filesep,'c_api.h']);
    catch ME
        msg = ['**********************************************************************************\n'...
               '代理模型依赖于 MinGW-w64 C/C++ 编译器, 要安装该编译器, 请使用“附加功能”菜单.\n'...
               '1. 在 MATLAB 主页选项卡的环境部分, 点击附加功能 -> 获取附加功能.\n'...
               '2. 搜索 MinGW 并安装.\n'...
               'The surrogate model relies on the MinGW-w64 C/C++ compiler, to install it, please \n'...
               'use the "Add-ons" menu.\n'...
               '1. In the ENVIRONMENT section of the MATLAB HOME tab, click Add-ons -> Get Add-ons.\n'...
               '2. Search for MinGW and install it.\n'...
               '**********************************************************************************'];
        causeException = MException(ME.identifier, msg);
        ME = addCause(ME,causeException);
        throw(ME);
    end
end
%% Prepare raw data
ROWS = uint64(size(Xtrain, 1)); 
COLS = uint64(size(Xtrain, 2));
Xtrain = Xtrain';   % DLL is row-based, and matlab is column-based
%% Prepare feature pointers
data = libpointer('singlePtr', single(Xtrain));
dmatrix = libpointer;
dmatrix_ptr = libpointer('voidPtrPtr', dmatrix);
calllib('xgboost', 'XGDMatrixCreateFromMat', data, ROWS, COLS, -1, dmatrix_ptr);
%% Prepare labels pointers
labels = libpointer('singlePtr',single(ytrain));
calllib('xgboost', 'XGDMatrixSetFloatInfo', dmatrix, 'label', labels, ROWS);
%% Create booster
eval_dmats_size = uint64(1);
booster_handle = libpointer;
booster_handle_ptr = libpointer('voidPtrPtr', booster_handle);
calllib('xgboost', 'XGBoosterCreate', dmatrix_ptr, eval_dmats_size, booster_handle_ptr);
%% Set params
for i=1:length(param_fields)
    eval(['calllib(''xgboost'', ''XGBoosterSetParam'', booster_handle, ''' param_fields{i} ''', ''' eval(['params.' param_fields{i}]) ''');'])
end
%% Train
for iter = 0:max_num_iters
    calllib('xgboost', 'XGBoosterUpdateOneIter', booster_handle, int32(iter), dmatrix);
end
%% Get the model
model                = struct;
model.booster_handle = booster_handle;
model.params         = params;        
%% Free all the internal structure to prevent  memory leak
if exist('dmatrix','var')
    calllib('xgboost', 'XGDMatrixFree', dmatrix); 
    clear dmatrix;
end