 function [IsIndex] = InfillSelection(PopDecs, decs, PopObjs, objs, n_sel)
% NDS-MPA infill solutions selection
    [N, ~] = size(PopObjs);
    %% Only the non-dominant solution is considered.
    R = 1 : N;
    lia = ~ismember(PopDecs, decs, 'rows');
    [FrontNo, MaxNo] = NDSort(PopObjs, N); 
    FrontNo = FrontNo';
    
    mix_objs = [PopObjs;objs];
    z       = min(mix_objs, [], 1);
    znad    = max(mix_objs, [], 1);
    PopObjs = (PopObjs-repmat(z,N,1))./repmat(znad-z ,N,1);
    objs    = (objs-repmat(z,size(objs,1),1))./repmat(znad-z,size(objs,1),1);
    for F = 1 : MaxNo
        RF = R(lia & (FrontNo==F));
        if ~isempty(RF)
            break;
        end
    end
    R = RF;
    IsIndex = [];
    [N, ~] = size(PopObjs); 
    %% Main process of NDS-MPA
    while numel(IsIndex) < n_sel && numel(R) > 0
        dis = pdist2(PopObjs(R, :), objs);
        dis = sort(dis, 2);
        dis_sum = sum(dis(:, 1:8), 2);
        [~, I] = max(dis_sum);
        IsIndex = [IsIndex R(I)];
        objs = [objs; PopObjs(R(I), :)];
        R(I) = [];
    end
 end

 

