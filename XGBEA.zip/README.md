本代码依赖[PlatEMO V3.2+](https://github.com/BIMK/PlatEMO)运行，解压*XGBEA.zip*，并将整个 *XGBEA* 文件夹放到 PlatEMO目录 PlatEMO\Algorithms\Multi-objective optimization 下，通过 PlatEMO GUI或者 Command 调用运行。

This code runs on [PlatEMO V3.2+](https://github.com/BIMK/PlatEMO). Please unzip *XGBEA.zip*, and put the whole folder *XGBEA* in the directory *PlatEMO\Algorithms\Multi-objective optimization* of PlatEMO, and run it by PlatEMO GUI or command.

