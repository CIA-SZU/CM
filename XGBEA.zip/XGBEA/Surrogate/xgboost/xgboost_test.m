function Yhat = xgboost_test(Xtest, model)
%% DLL function
% % % % % % % % % % % % % % % % % % % % % % % % 
% int XGBoosterLoadModel(   BoosterHandle 	handle,
%                           const char * 	fname 
% )	
% Description:  Load model from existing file.
% Parameters:
%       handle	handle
%       fname   file name
% Returns:
%       0 when success, -1 when failure happens
% % % % % % % % % % % % % % % % % % % % % % % % 
% int XGBoosterPredict( BoosterHandle 	handle,
%                       DMatrixHandle   dmat,
%                       int             option_mask,
%                       unsigned        ntree_limit,
%                       int             training,
%                       bst_ulong * 	output_length,
%                       const float ** 	out_result 
% )
% Description:  make prediction based on dmat
% Parameters:
%       handle          handle
%       dmat            data matrix
%       option_mask     bit-mask of options taken in prediction, possible values 
%                       0:normal prediction 
%                       1:output margin instead of transformed value 
%                       2:output leaf index of trees instead of leaf value, note leaf index is unique per tree 
%                       4:output feature contributions to individual predictions
%       ntree_limit     limit number of trees used for prediction, this is only valid for boosted trees 
%                       when the parameter is set to 0, we will use all the trees
%       training        Whether the prediction function is used as part of a training loop.
%                       0 for no and 1 for yes.
%       output_length   used to store length of returning result
%       out_result      used to set a pointer to array
% Returns:
%       0 when success, -1 when failure happens
% % % % % % % % % % % % % % % % % % % % % % % % 
%% Get the booster handle
booster_handle = model.booster_handle; 
%% Prepare raw data
ROWS = uint64(size(Xtest,1));
COLS = uint64(size(Xtest,2));
Xtest = Xtest'; 
%% Prepare pointers
data = libpointer('singlePtr',single(Xtest));  
dmatrix = libpointer;
dmatrix_ptr = libpointer('voidPtrPtr', dmatrix);
calllib('xgboost', 'XGDMatrixCreateFromMat', data, ROWS, COLS, -1, dmatrix_ptr);
%% Make prediction
output_length = uint64(0);
output_length_ptr = libpointer('uint64Ptr', output_length);
output_result = libpointer('singlePtr');
output_result_ptr = libpointer('singlePtrPtr', output_result);
calllib('xgboost', 'XGBoosterPredict', booster_handle, dmatrix, 0, 0, 0, output_length_ptr, output_result_ptr);
%% Get predict value.
n_output = output_length_ptr.Value;
setdatatype(output_result, 'singlePtr', n_output);
Yhat = double(output_result.Value); 
%% Free all the internal structure to prevent  memory leak
if exist('dmatrix','var')
    calllib('xgboost', 'XGDMatrixFree', dmatrix); 
    clear dmatrix;
end