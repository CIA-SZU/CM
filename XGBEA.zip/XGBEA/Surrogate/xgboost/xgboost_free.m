function xgboost_free(Model)
    calllib('xgboost', 'XGBoosterFree', Model.booster_handle); 
end

