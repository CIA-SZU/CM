function XGBModels = XGBTrain(decs, objs, depthes)
% Train XGboost Models
% Input:
%         decs : a Q×R matrix of Q samples with R features.
%         objs : a Q×M matrix of Q samples with M objective functions.
%         depths: a 1×M vecctor of different depth on each objective function.
% Output:
%         XGBModels  : a 1×M cell stores M XGBoost Models. 
    [~, M] = size(objs);
    XGBModels = cell(1, M);
    for m = 1 : M
        XGBModels{m} = xgboost_train(decs, objs(:,m), depthes(m));
    end
end

