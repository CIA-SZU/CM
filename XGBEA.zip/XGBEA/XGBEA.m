classdef XGBEA < ALGORITHM
% <multi/many> <real> <expensive>
% n_sel      ---  5 --- Number of infill solutions.
    methods
        function main(Algorithm,Problem)
          %% Parameter setting
            [n_sel] = Algorithm.ParameterSet( 5);
            max_gen = 20;
            CV = 5;
          %% Generate initial population and archive of evaluated solutions
            NI       = 11 * Problem.D - 1;
            Nset     = Problem.N;
            P        = UniformPoint(NI, Problem.D, 'Latin');
            SArchive = SOLUTION(repmat(Problem.upper-Problem.lower,NI,1).*P+repmat(Problem.lower,NI,1));
            PopDecs  = SArchive.decs;
            PopObjs  = SArchive.objs;
            depth    = XGBChooseParams(PopDecs, PopObjs, CV);
            [z,znad] = deal(min(PopObjs),max(PopObjs));
          %% Optimization 
            while Algorithm.NotTerminated(SArchive)   
                Problem.N = min(Nset, numel(SArchive));
		      %% Train Boosting Trees Surrogates
                decs   = SArchive.decs;
                objs   = SArchive.objs;
                Models = XGBTrain(decs, objs, depth);        
			  %% Evolve
                PopDecs = decs;
                PopObjs =objs;
                gen = 1;
                while gen <= max_gen
                    Lp = PFShapeEstimate(PopObjs, z, znad);
                 %% Generate offspring
                    OffDecs = OperatorGA(PopDecs);
                 %% Predict the objs using xgboost models
					OffObjs = XGBPredict(Models, OffDecs);
				 %% Combination
                    PopDecs = [PopDecs; OffDecs];
                    PopObjs = [PopObjs; OffObjs];
                 %% Environmental Selection
					[S, z, znad]  = EnvironmentalSelection(PopObjs, Problem.N, Lp);
					PopDecs = PopDecs(S, :);
                    PopObjs = PopObjs(S, :);
				 %% Update Counter
                    gen = gen + 1;
                end
			  %% Choose the infill solutions
                 ISIndex = InfillSelection(PopDecs, SArchive.decs, PopObjs, SArchive.objs, n_sel);
                
                if numel(ISIndex) > 0
                  %% Expensive evaluation
                    ISSolution = SOLUTION(PopDecs(ISIndex, :)); 
                    SArchive = [SArchive ISSolution]; 
                end
              %% Free booster handles 
                XGBFree(Models);
            end
        end
    end
end
