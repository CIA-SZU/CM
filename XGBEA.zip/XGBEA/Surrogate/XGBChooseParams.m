function depth_params = XGBChooseParams(decs, objs, CV)
% Selecting the appropriate tree depth and determining whether to  take the 
% logarithm of the objective value 
% Input:
%       decs    : a Q×R matrix with Q samples of R features.
%       objs    : a Q×M matrix represents the true objective values.
%       CV      : CV fold cross-validation
% Output:
%       depth_params : The depth of the trees on each objective function
[N, M] = size(objs);
depthes = [2 3 4 5 6];
num_depth = numel(depthes);
depth_params = zeros(1, M);
shuffle = randperm(N);
decs = decs(shuffle, :);
objs = objs(shuffle, :);
p = size(decs, 2);
num_eachpart = floor(N/CV);
%% CV 寻找合适树深度
for m = 1 : M
    ADJ_R2_dep = zeros(1, num_depth);
    for depth_index = 1 : num_depth
        adj_r2 = 0;
        for cv = 1 : CV
            pred_start_index = (cv-1)*num_eachpart+1;
            if cv == CV
                train_index = 1:pred_start_index-1;
                pred_index = pred_start_index : N;
            else
                pred_end_index = cv*num_eachpart;
                train_index = [1:pred_start_index-1, pred_end_index+1:N];
                pred_index = pred_start_index : pred_end_index;
            end
            n = numel(pred_index);
            ModelsCVTemp = xgboost_train(decs(train_index,:), objs(train_index,m), depthes(depth_index));
            ypred_cv_temp = xgboost_test(decs(pred_index,:), ModelsCVTemp);
            xgboost_free(ModelsCVTemp);
            r2 = 1 - sum((ypred_cv_temp - objs(pred_index, m)).^2)/sum((mean(objs(pred_index, m)) - objs(pred_index, m)).^2);
            adj_r2 = adj_r2 + 1 - ((1 - r2)*(n-1))/(n-p-1);
        end
        ADJ_R2_dep(depth_index) = adj_r2/CV;
    end
    [~, param_index] = max(ADJ_R2_dep);
    depth_params(m) = depthes(param_index);
end
end

