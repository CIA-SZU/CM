function XGBModels = XGBTrain(decs, objs, depthes)
    [~, M] = size(objs);
    XGBModels = cell(1, M);
    for m = 1 : M
        XGBModels{m} = xgboost_train(decs, objs(:,m), depthes(m));
    end
end

